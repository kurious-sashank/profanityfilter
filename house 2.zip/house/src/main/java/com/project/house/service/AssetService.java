package com.project.house.service;

import com.project.house.model.Asset;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

@Service
public class AssetService {
  private Map<String, Asset> assetMap = new HashMap<>();

  public void addAsset(Asset asset) {
    assetMap.put(asset.getAssetId(), asset);
  }

  public Set<String> getAssets() {
    return assetMap.keySet();
  }

  public boolean hasAsset(String assetId){
    return assetMap.containsKey(assetId);
  }
}
