package com.project.house.resource;

import com.project.house.model.TaskAssignment;
import com.project.house.service.TaskAssignmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotBlank;

@RestController
public class AdminResource {

  @Autowired private TaskAssignmentService taskAssignmentService;

  @PostMapping("/allocate-task")
  public ResponseEntity addAsset(@RequestBody @Validated TaskAssignment assignment) {
    ResponseEntity responseEntity = new ResponseEntity(HttpStatus.CREATED);
    try {
      taskAssignmentService.allocateTask(assignment);
    } catch (Exception ex) {
      responseEntity = new ResponseEntity(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
    }
    return responseEntity;
  }

  @GetMapping("/get-tasks-for-worker/{workerId}")
  public ResponseEntity getAllTasksByWorkerId(
      @NotBlank(message = "Worker must not be empty") @PathVariable("workerId") String workerId) {
    return new ResponseEntity<>(
        taskAssignmentService.getAllTasksByWorkerId(workerId), HttpStatus.OK);
  }
}
