package com.project.house.model;

import javax.validation.constraints.NotBlank;

public class Asset {
    @NotBlank(message = "Asset Id cannot be empty")
    private String assetId;
    private String assetName;

    public String getAssetId() {
        return assetId;
    }

    public void setAssetId(String assetId) {
        this.assetId = assetId;
    }

    public String getAssetName() {
        return assetName;
    }

    public void setAssetName(String assetName) {
        this.assetName = assetName;
    }
}
