package com.project.house.service;

import com.project.house.model.Worker;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

@Service
public class WorkerService {
  private Map<String, Worker> workerMap = new HashMap<>();

  public void addWorker(Worker worker) {
    workerMap.put(worker.getWorkerId(), worker);
  }

  public Set<String> getWorkers() {
    return workerMap.keySet();
  }

  public boolean hasWorker(String workerId) {
    return workerMap.containsKey(workerId);
  }
}
