package com.project.house.model;

import javax.validation.constraints.NotBlank;

public class Task {
    @NotBlank(message = "Task Id cannot be empty")
    private String taskId;
    private String taskName;

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }
}
