package com.project.house.resource;

import com.project.house.model.Asset;
import com.project.house.service.AssetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AssetResource {

  @Autowired AssetService assetService;

  @PostMapping("/add-asset")
  public ResponseEntity addAsset(@RequestBody @Validated Asset asset) {
    assetService.addAsset(asset);
    return new ResponseEntity(HttpStatus.CREATED);
  }

  @GetMapping("/assets/all")
  public ResponseEntity getAllAssets() {
    return new ResponseEntity(assetService.getAssets(), HttpStatus.OK);
  }
}
