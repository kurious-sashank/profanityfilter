package com.project.house.service;

import com.project.house.model.TaskAssignment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class TaskAssignmentService {

  @Autowired private AssetService assetService;

  @Autowired private TaskService taskService;

  @Autowired private WorkerService workerService;

  private Map<String, List<TaskAssignment>> taskAssignmentMap = new HashMap<>();

  public void allocateTask(TaskAssignment taskAssignment) throws Exception {
    if (!workerService.hasWorker(taskAssignment.getWorkerId())) {
      throw new Exception("No Worker with id : " + taskAssignment.getWorkerId() + " found");
    }
    if (!assetService.hasAsset(taskAssignment.getAssetId())) {
      throw new Exception("No Asset with id : " + taskAssignment.getAssetId() + " found");
    }
    if (!taskService.hasTask(taskAssignment.getTaskId())) {
      throw new Exception("No Task with id : " + taskAssignment.getTaskId() + " found");
    }
    if (taskAssignmentMap.containsKey(taskAssignment.getWorkerId())) {
      taskAssignmentMap.get(taskAssignment.getWorkerId()).add(taskAssignment);
    } else {
      List<TaskAssignment> taskAssignments = new ArrayList<>();
      taskAssignments.add(taskAssignment);
      taskAssignmentMap.put(taskAssignment.getWorkerId(), taskAssignments);
    }
  }

  public List<String> getAllTasksByWorkerId(String workerId) {
    List<TaskAssignment> taskAssignments = taskAssignmentMap.get(workerId);
    List<String> tasks = new ArrayList<>();
    for (TaskAssignment taskAssignment : taskAssignments) {
      tasks.add(taskAssignment.getTaskId());
    }
    return tasks;
  }
}
