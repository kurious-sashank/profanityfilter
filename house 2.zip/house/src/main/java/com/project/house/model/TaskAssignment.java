package com.project.house.model;

import javax.validation.constraints.NotBlank;
import java.time.LocalDateTime;

public class TaskAssignment {

    @NotBlank(message = "Asset Id cannot be empty")
    String assetId;
    @NotBlank(message = "Worker Id cannot be empty")
    String workerId;
    @NotBlank(message = "Task Id cannot be empty")
    String taskId;
    LocalDateTime timeOfAllocation;
    LocalDateTime taskToBePerformedBy;

    public String getAssetId() {
        return assetId;
    }

    public void setAssetId(String assetId) {
        this.assetId = assetId;
    }

    public String getWorkerId() {
        return workerId;
    }

    public void setWorkerId(String workerId) {
        this.workerId = workerId;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public LocalDateTime getTimeOfAllocation() {
        return timeOfAllocation;
    }

    public void setTimeOfAllocation(LocalDateTime timeOfAllocation) {
        this.timeOfAllocation = timeOfAllocation;
    }

    public LocalDateTime getTaskToBePerformedBy() {
        return taskToBePerformedBy;
    }

    public void setTaskToBePerformedBy(LocalDateTime taskToBePerformedBy) {
        this.taskToBePerformedBy = taskToBePerformedBy;
    }
}
