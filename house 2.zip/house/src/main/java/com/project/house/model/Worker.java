package com.project.house.model;

import javax.validation.constraints.NotBlank;

public class Worker {
    @NotBlank(message = "Asset Id cannot be empty")
    private String workerId;
    private String workerName;

    public String getWorkerId() {
        return workerId;
    }

    public void setWorkerId(String workerId) {
        this.workerId = workerId;
    }

    public String getWorkerName() {
        return workerName;
    }

    public void setWorkerName(String workerName) {
        this.workerName = workerName;
    }
}
