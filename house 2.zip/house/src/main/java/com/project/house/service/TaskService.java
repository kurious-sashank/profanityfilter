package com.project.house.service;

import com.project.house.model.Task;
import com.project.house.model.Worker;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

@Service
public class TaskService {

  private Map<String, Task> taskMap = new HashMap<>();

  public void addTask(Task task) {
    taskMap.put(task.getTaskId(), task);
  }

  public Set<String> getTasks() {
    return taskMap.keySet();
  }


    public boolean hasTask(String taskId){
        return taskMap.containsKey(taskId);
    }
}
